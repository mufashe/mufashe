from django.apps import AppConfig


class LeavemanConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'leaveMan'
